
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, EmailStr
from uuid import uuid4, UUID

app = FastAPI()

# In-memory storage
users_db = {}

# User schema
class User(BaseModel):
    name: str
    email: EmailStr
    age: int

@app.post("/users")
def create_user(user: User):
    user_id = uuid4()
    users_db[user_id] = user
    return {"id": user_id, **user.dict()}

@app.get("/users/{user_id}")
def read_user(user_id: UUID):
    user = users_db.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"id": user_id, **user.dict()}

@app.put("/users/{user_id}")
def update_user(user_id: UUID, updated_user: User):
    if user_id not in users_db:
        raise HTTPException(status_code=404, detail="User not found")
    users_db[user_id] = updated_user
    return {"id": user_id, **updated_user.dict()}

@app.delete("/users/{user_id}")
def delete_user(user_id: UUID):
    if user_id not in users_db:
        raise HTTPException(status_code=404, detail="User not found")
    del users_db[user_id]
    return {"message": "User deleted successfully"}
